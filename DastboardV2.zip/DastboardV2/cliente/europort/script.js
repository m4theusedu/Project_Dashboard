let totalVpnsConectadas = 0;

function loadPage(page) {
  const content = document.getElementById('mainContent');
  let html = '';

  switch (page) {

    case 'dashboard':
      html = `
    <h1 class="Titulo">Dashboard</h1>
    
    <div class="cards-dashboard">
      <div class="card azul" onclick="mostrarTabela('licencas')">
        <h4 >Licenças Contratadas</h4>
        <p>3</p>
      </div>
      <div class="card verde" onclick="mostrarTabela('vpnsConectadas')">
        <h4>VPNs Conectadas</h4>
        <p id="on_Vpns"></p>
      </div>
      <div class="card vermelho" onclick="mostrarTabela('vpnsDesconectadas')">
        <h4>VPNs Desconectadas</h4>
        <p id="off_Vpns"></p>
      </div>
      <div class="card amarelo" onclick="mostrarInfoDataCenter()">
      <h4>Data Center</h4>
      <p>SP2</p>
      </div>
    </div>
  `;
      break;

    case 'empresa':
      html = `
    <h1 class="Titulo">Informações da Empresa</h1>
    <div class="empresa-info">
      <div class="info-item">
        <h3>Razão Social</h3><p> EUROPORT CODOMÍNIO </p>
      </div>
      <div class="info-item">
        <h3>Data de Fundação</h3><p>25 de Maio de 1988</p>
      </div>
      <div class="info-item">
        <h3>CNPJ</h3><p>58.585.585/581-58</p>
      </div>
      <div class="info-item">
        <h3>Inscrição Estadual</h3><p>789.654.321.000</p>
      </div>
      <div class="info-item">
        <h3>Endereço</h3><p>Av. Marvel, 2019 - , Petrolina PE</p>
      </div>
      <div class="info-item">
        <h3>Responsável Legal</h3><p> Lucas Ferraz </p>
      </div>
    </div>
  `;
      break;

    case 'suporte':
      html = `
        <h1 class="Titulo" >Suporte</h1>
        <div class="card_suporte">
          <button class="nova_solit" onclick="window.location.href='https://lp.ntechnetwork.com.br/'">Solicitar Suporte</button>
        </div>
      `;
      break;

    default:
      html = '<h1>Bem-vindo!</h1>';


  } 

  content.innerHTML = html;

  if (page === 'dashboard') {
    fetch('/DastboardV2/adm/shared/dados.php')
      .then(response => response.json())
      .then(data => {
        const totalConectadas = data.filter(item => item.status == 1 && item.id_empresa == "Europort").length;
        const totalDesconectadas = data.filter(item => item.status != 1 && item.id_empresa == "Europort").length;

        const resumoConectadas = document.getElementById('on_Vpns');
        if (resumoConectadas) resumoConectadas.textContent = `${totalConectadas}`;

        const resumoDesconectadas = document.getElementById('off_Vpns');
        if (resumoDesconectadas) resumoDesconectadas.textContent = `${totalDesconectadas}`;
      })
      .catch(error => {
        console.error('Erro ao buscar dados no dashboard:', error);
      });
  }

}




function mostrarTabela(tipo) {
  let tabela = '';
  if (tipo === 'licencas') {

    tabela = `
      <h2>Licenças Contratadas</h2>

      <button id="voltar" class ="ext_card">Sair</button>
      <table>
        <thead>
          <tr><th>ID</th><th>Tipo</th><th>Status</th><th>Validade</th></tr>
        </thead>
        <tbody>
          <tr><td>005</td> <td>Office 365</td> <td>Ativa</td> <td>2025-12-31</td></tr>
          <tr><td>002</td><td>Antivírus</td><td>Expirada</td><td>2023-10-10</td></tr>
          <tr><td>003</td><td>VPN Pro</td><td>Ativa</td><td>2024-09-30</td></tr>
        </tbody>
      </table>
    `;




  } else if (tipo === 'vpnsConectadas') {
    tabela = `
    <h1>VPNs Conectadas</h1>
    <button id="voltar" class="ext_card">Sair</button>
    <table>
      <thead>
        <tr><th>ID</th><th>IP</th><th>Status</th></tr>
      </thead>
      <tbody id="tabela-body"></tbody>
    </table>
  `;


    document.getElementById('mainContent').innerHTML = tabela;
    adicionarBotaoVoltar();


    fetch('/DastboardV2/adm/shared/dados.php')
      .then(response => response.json())
      .then(data => {
        const corpo = document.getElementById('tabela-body');
        const contador = document.getElementById('contador');
        const totalConectadas = data.filter(item => item.status == 1 && item.id_empresa === "Europort").length;

        const resumo = document.getElementById('on_Vpns');
        if (resumo) {
          resumo.textContent = `Foram encontradas ${totalConectadas} VPNs conectadas.`;
        } else {
          console.warn('Elemento #resumoVpns não encontrado.');
        }

        totalVpnsConectadas = data.filter(item => item.status == 1).length;




        if (data.length === 0) {
          corpo.innerHTML = '<tr><td colspan="3">Nenhuma Vpn conectada a Europort</td></tr>';
          return;
        }

        data.forEach(item => {
  if (item.status != 1 || item.id_empresa !== "Europort") {
    return; 
  }

          const status = item.status == 1
            ? '<span><svg class="icone" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><title>Ícone de Check</title><circle cx="8" cy="8" r="8"/></svg></span>'
            : '<span><svg class="icone2" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><title>Ícone de Check</title><circle cx="8" cy="8" r="8"/></svg></span>';

          corpo.innerHTML += `
          <tr>
            <td>${item.id_empresa}</td>
            <td>${item.ip}</td>
            <td>${status}</td>
          </tr>
        `;
        });
      })
      .catch(error => {
        document.getElementById('tabela-body').innerHTML =
          '<tr><td colspan="3">Erro ao carregar dados.</td></tr>';
        console.error('Erro ao buscar dados:', error);
      });

    return;

  } else if (tipo === 'vpnsDesconectadas') {
    tabela = `
      <h1>VPNs Desconectadas</h1>
      <button id="voltar" class="ext_card">Sair</button>
    <p id="contador"></p>
    <table>
      <thead>
        <tr><th>ID</th><th>IP</th><th>Status</th></tr>
      </thead>
      <tbody id="tabela-body"></tbody>
    </table>
    `;


    document.getElementById('mainContent').innerHTML = tabela;
    adicionarBotaoVoltar();
    fetch('/DastboardV2/adm/shared/dados.php')
      .then(response => response.json())
      .then(data => {
        const corpo = document.getElementById('tabela-body');
        const contador = document.getElementById('contador');

        const europortData = data.filter(item => item.id_empresa === "Europort");
        const totalConectadas = data.filter(item => item.status == 0 && item.id_empresa === "Europort").length;
        const resumo = document.getElementById('off_Vpns');
        
        if (resumo) {
          resumo.textContent = `Foram encontradas ${totalConectadas} VPNs conectadas.`;
        } else {
          console.warn('Elemento #resumoVpns não encontrado.');
        }

        totalVpnsConectadas = data.filter(item => item.status == 1).length;

            //  off 

        if (data.length === 0) {
          corpo.innerHTML = '<tr><td colspan="3">Nenhum registro encontrado.</td></tr>';
          return;
        }

        data.forEach(item => {
          if (item.status === "1" || item.status === 1) {
            return;
          }

          if (item.id_empresa !== "Europort") {
            return;
          }
          const status = item.status == 0
            ? '<span><svg class="icone2" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><title>Ícone de Check</title><circle cx="8" cy="8" r="8"/></svg></span>'
            : '<span><svg class="icone" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><title>Ícone de Check</title><circle cx="8" cy="8" r="8"/></svg></span>';

          corpo.innerHTML += `
          <tr>
            <td>${item.id_empresa}</td>
            <td>${item.ip}</td>
            <td>${status}</td>
          </tr>
        `;
        });
      })
      .catch(error => {
        document.getElementById('tabela-body').innerHTML =
          '<tr><td colspan="3">Erro ao carregar dados.</td></tr>';
        console.error('Erro ao buscar dados:', error);
      });

    return;
  }


  document.getElementById('mainContent').innerHTML = tabela;
  adicionarBotaoVoltar();
}

function mostrarInfoDataCenter() {
  const popupExistente = document.getElementById('popupOverlay');
  if (popupExistente) {
    fecharPopup();
  }
  const popupHTML = `
    <div class="popup-overlay" id="popupOverlay">
      <div class="popup">
        <h2>Data Center: SP2</h2>
        <p><strong>Localização:</strong> São Paulo</p>
        <p><strong>Fornecedor:</strong> ODATA</p>
        <p><strong>Servidores ativos:</strong> 1</p>
        <button onclick="fecharPopup()">Fechar</button>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', popupHTML);

  document.getElementById('popupOverlay').style.display = 'flex';
}

function adicionarBotaoVoltar() {
  const botao = document.getElementById('voltar');
  if (botao) {
    botao.addEventListener('click', () => loadPage('dashboard'));
  }
}


function fecharPopup() {

  const popupOverlay = document.getElementById('popupOverlay');
  if (popupOverlay) {
    popupOverlay.style.display = 'none';
    document.body.removeChild(popupOverlay);
  }
}

loadPage('dashboard');
