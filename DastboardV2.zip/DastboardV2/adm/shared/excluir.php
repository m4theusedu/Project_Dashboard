<?php
$conn = new mysqli("localhost", "root", "", "sistema");
if ($conn->connect_error) die("Erro: " . $conn->connect_error);

$id = $_POST['id'];

$stmt = $conn->prepare("DELETE FROM contas WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "Conta excluída com sucesso.";
} else {
    echo "Erro ao excluir.";
}

$stmt->close();
$conn->close();
?>
