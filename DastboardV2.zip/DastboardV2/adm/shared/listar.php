<?php
$conn = new mysqli("localhost", "root", "", "sistema");
if ($conn->connect_error) die("Erro: " . $conn->connect_error);

$result = $conn->query("SELECT id, usuario, identificador FROM contas");

$contas = [];
while ($row = $result->fetch_assoc()) {
    $contas[] = $row;
}

echo json_encode($contas);
$conn->close();
?>
