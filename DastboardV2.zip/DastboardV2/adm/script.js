let totalVpnsConectadas = 0;

document.getElementById("meuSelect").addEventListener("change", function () {
  const destino = this.value;
  if (destino === "europort") {
    window.location.href = "http://localhost/DastboardV2/adm/europort/index.html";

  }

  if (destino === "kapa") {
    window.location.href = "http://localhost/DastboardV2/adm/Kapa/index.html";

  }
});



function loadPage(page) {
  const content = document.getElementById('mainContent');
  let html = '';

  switch (page) {

    case 'dashboard':
      html = `
    <h1>Dashboard</h1>
    
    <div class="cards-dashboard">
      <div class="card azul" onclick="mostrarTabela('licencas')">
        <h4 >Licenças Contratadas</h4>
        <p>3</p>
      </div>
      <div class="card verde" onclick="mostrarTabela('vpnsConectadas')">
        <h4>VPNs Conectadas</h4>
        <p class="fonte_card" id="on_Vpns"></p>
      </div>
      <div class="card vermelho" onclick="mostrarTabela('vpnsDesconectadas')">
        <h4>VPNs Desconectadas</h4>
        <p id="off_Vpns"></p>
      </div>
      <div class="card amarelo" onclick="mostrarInfoDataCenter()">
      <h4>Data Center</h4>
      <p>SP1</p>
        
      </div>
    </div>
  `;
      break;

    case 'empresa':
      html = `
    <h1>Informações da Empresa</h1>
    <div class="empresa-info">
      <div class="info-item">
        <h3>Razão Social</h3><p>NTECH NETWORK e COMUNICAÇÃO LTDA</p>
      </div>
      <div class="info-item">
        <h3>Data de Fundação</h3><p>9 DE OUTUBRO DE 2017</p>
      </div>
      <div class="info-item">
        <h3>CNPJ</h3><p>28.827.070/0001-37/p>
      </div>
      <div class="info-item">
        <h3>Inscrição Estadual</h3><p>004494130.00-41</p>
      </div>
      <div class="info-item">
        <h3>Endereço</h3><p>Rua Prefeito Chagas, n°100</p>
      </div>
      <div class="info-item">
        <h3>Responsável Legal</h3><p>Nilton Cesar da Silva</p>
      </div>
    </div>
  `;
      break;


    case 'infraestrutura':
      html = `
    <h1>Infraestrutura</h1>
    <div class="infraestrutura-info">
      <div class="info-item">
        <h3>Servidores - <span id="dc-atual">SP1</span></h3>
        <ul class="servidores-list" id="servidores-list">
          <!-- Lista será preenchida via JS -->
        </ul>
      </div>
      <div class="info-item">
        <h3>Data Centers</h3>
        <button class="dc-btn" data-dc="SP1">SP1</button>
        <button class="dc-btn" data-dc="SP2">SP2</button>
      </div>
    </div>
  `;

      setTimeout(() => {
        const servidoresPorDC = {
          SP1: [
            { nome: 'Servidor 01', status: 'on' },
            { nome: 'Servidor 02', status: 'on' },
            { nome: 'Servidor 03', status: 'off'},
            { nome: 'Servidor 04', status: 'on' }
          ],
          SP2: [
            { nome: 'Servidor 05', status: 'on' },
            { nome: 'Servidor 06', status: 'off' },
            { nome: 'Servidor 07', status: 'off' }
          ]
        };

        const lista = document.getElementById('servidores-list');
        const dcAtual = document.getElementById('dc-atual');

        function renderServidores(dc) {
          dcAtual.textContent = dc;
          lista.innerHTML = '';
          servidoresPorDC[dc].forEach(s => {
            const li = document.createElement('li');
            li.className = s.status === 'on' ? 'serv_on' : 'serv_off';
            li.textContent = `${s.nome} - ${s.status === 'on' ? 'Online' : 'Offline'}`;
            lista.appendChild(li);
          });
        }

        document.querySelectorAll('.dc-btn').forEach(btn => {
          btn.addEventListener('click', () => renderServidores(btn.dataset.dc));
        });

        renderServidores('SP1');
      });
      break;

    case 'gestao':
      html = `
    <button id="abrirPopup" class="BotaoCadastroConta">+</button>

    <h1 class="title_gestao">Gestão de Contas</h1>
    <ul id="listaContas" class="list"></ul>

    <div id="popup" class="popup_gestao" style="display:none;">
      <div class="popup-content">
        <span class="fechar" id="fecharPopup">&times;</span>
        <h2>Nova Conta</h2>
        <form id="contaForm">
          <input type="text" id="usuario" placeholder="Usuário" required class="input_new_conta">
          <input type="password" id="senha" placeholder="Senha" required class="input_new_conta">
          <input type="text" id="identificador" placeholder="Identificador" required class="input_new_conta">
          <button type="submit" class="cadastrar_btn">Cadastrar</button>
        </form>
        <p id="mensagem"></p>
      </div>
    </div>
  `;

      content.innerHTML = html;

      setTimeout(() => {
        const popup = document.getElementById("popup");
        const abrirPopup = document.getElementById("abrirPopup");
        const fecharPopup = document.getElementById("fecharPopup");

        abrirPopup.addEventListener("click", () => {
          popup.style.display = "block";
        });

        fecharPopup.addEventListener("click", () => {
          popup.style.display = "none";
        });

        window.addEventListener("click", function (event) {
          if (event.target === popup) {
            popup.style.display = "none";
          }
        });

        document.addEventListener("keydown", function (event) {
          if (event.key === "Escape") {
            popup.style.display = "none";
          }
        });

        document.getElementById("contaForm").addEventListener("submit", function (e) {
          e.preventDefault();

          const usuario = document.getElementById("usuario").value.trim();
          const senha = document.getElementById("senha").value.trim();
          const identificador = document.getElementById("identificador").value.trim();

          console.log("Enviando dados:", { usuario, senha, identificador });

          if (!usuario || !senha || !identificador) {
            document.getElementById("mensagem").innerText = "Todos os campos são obrigatórios.";
            return;
          }

          fetch("/DastboardV2/adm/shared/adicionar.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `usuario=${encodeURIComponent(usuario)}&senha=${encodeURIComponent(senha)}&identificador=${encodeURIComponent(identificador)}`
          })
            .then(res => res.text())
            .then(data => {
              console.log("Resposta do servidor:", data);
              document.getElementById("mensagem").innerText = data;
              document.getElementById("contaForm").reset();
              carregarContas();
            })
            .catch(err => {
              console.error("Erro ao cadastrar:", err);
              document.getElementById("mensagem").innerText = "Erro ao cadastrar conta.";
            });
        });

        carregarContas();
      }, 0);


      function carregarContas() {
        fetch("/DastboardV2/adm/shared/listar.php")
          .then(res => res.json())
          .then(data => {
            const lista = document.getElementById("listaContas");
            lista.innerHTML = "";

            data.forEach(conta => {
              const li = document.createElement("li");
              li.innerHTML = `
            <strong>${conta.usuario}</strong> (${conta.identificador})
            <div class="acoes">
              <button class="excluir-btn" data-id="${conta.id}">Excluir Conta</button>
            </div>
          `;
              li.addEventListener("click", function (e) {
                if (e.target.tagName.toLowerCase() === 'button') return;
                document.querySelectorAll("#listaContas li").forEach(el => el.classList.remove("mostrar"));
                li.classList.toggle("mostrar");
              });
              lista.appendChild(li);
            });


            document.querySelectorAll(".excluir-btn").forEach(btn => {
              btn.addEventListener("click", function (e) {
                e.stopPropagation();
                const id = this.dataset.id;
                excluirConta(id);
              });
            });
          })
          .catch(() => {
            document.getElementById("listaContas").innerHTML = "<li>Erro ao carregar contas.</li>";
          });
      }

      function excluirConta(id) {
        fetch("/DastboardV2/adm/shared/excluir.php", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: `id=${id}`
        })
          .then(res => res.text())
          .then(msg => {
            alert(msg);
            carregarContas();
          });
      }

      break;




    case 'suporte':
      html = `
        <h1>Suporte</h1>
        <div class="card_suporte">
          <button class="nova_solit" onclick="window.location.href='https://lp.ntechnetwork.com.br/'">Nova Solicitação</button>

          <br></br>
          
        </div>
      `;
      break;
    default:
      html = '<h1>Bem-vindo!</h1>';
  }

  content.innerHTML = html;

  if (page === 'dashboard') {
    fetch('/DastboardV2/adm/shared/dados.php')

      .then(response => response.json())
      .then(data => {
        const totalConectadas = data.filter(item => item.status == 1).length;
        const totalDesconectadas = data.filter(item => item.status != 1).length;

        const resumoConectadas = document.getElementById('on_Vpns');
        if (resumoConectadas) resumoConectadas.textContent = `${totalConectadas}`;

        const resumoDesconectadas = document.getElementById('off_Vpns');
        if (resumoDesconectadas) resumoDesconectadas.textContent = `${totalDesconectadas}`;
      })
      .catch(error => {
        console.error('Erro ao buscar dados no dashboard:', error);
      });
  }

}

function mostrarTabela(tipo) {
  let tabela = '';
  if (tipo === 'licencas') {

    tabela = `
      <h2>Licenças Contratadas</h2>
      <button id="voltar" class ="ext_card">Sair</button>
     <table>
        <thead>
          <tr>
          <th>Tipo</th>
          <th>Status</th>
          <th>Validade</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>OData API Gateway</td>
            <td>Ativa</td>
            <td>31/12/2025</td>
          </tr>
          <tr>
          <td>Kaspersky</td>
          <td>Expirada</td>
          <td>15/06/2025</td>
          </tr>
          <tr>
          <td>VPN Pro</td>
          <td>Ativa</td>
          <td>03/8/2025</td>
          </tr>
        </tbody>
      </table>
    `;




  } else if (tipo === 'vpnsConectadas') {
    tabela = `
    <h1>VPNs Conectadas</h1>
    <button id="voltar" class="ext_card">Sair</button>
    <table>
      <thead >
        <tr><th>ID</th><th>IP</th><th>Status</th></tr>
      </thead>
      <tbody id="tabela-body"></tbody>
    </table>
  `;

    document.getElementById('mainContent').innerHTML = tabela;
    adicionarBotaoVoltar();
    carregarVpns()

  } else if (tipo === 'vpnsDesconectadas') {
    tabela = `
      <h1>VPNs Desconectadas</h1>
      <button id="voltar" class="ext_card">Sair</button>
    <table>
      <thead>
        <tr><th>ID</th><th>IP</th><th>Status</th></tr>
      </thead>
      <tbody id="tabela-body"></tbody>
    </table>
    `;

    document.getElementById('mainContent').innerHTML = tabela;
    adicionarBotaoVoltar();
    carregarVpnsDesconectadas()

  }

  document.getElementById('mainContent').innerHTML = tabela;
  adicionarBotaoVoltar();
}

function mostrarInfoDataCenter() {
  const popupExistente = document.getElementById('popupOverlay');
  if (popupExistente) {
    fecharPopup();
  }
  const popupHTML = `
    <div class="popup-overlay" id="popupOverlay">
      <div class="popup">
        <h2>Data Center: SP1 - SP2</h2>
        <p><strong>Fornecedor:</strong> ODATA</p>
        <p><strong>Localização:</strong> São Paulo</p>
        <p><strong>Servidores ativos:</strong> 4</p>
        <button onclick="fecharPopup()">Fechar</button>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', popupHTML);

  document.getElementById('popupOverlay').style.display = 'flex';
}

function adicionarBotaoVoltar() {
  const botao = document.getElementById('voltar');
  if (botao) {
    botao.addEventListener('click', () => loadPage('dashboard'));
  }
}


function fecharPopup() {

  const popupOverlay = document.getElementById('popupOverlay');
  if (popupOverlay) {
    popupOverlay.style.display = 'none';
    document.body.removeChild(popupOverlay);
  }
}

function carregarVpns(filtroEmpresa = null) {
  fetch('/DastboardV2/adm/shared/dados.php')

    .then(r => r.json())
    .then(data => {
      const corpo = document.getElementById('tabela-body');
      const resumo = document.getElementById('on_Vpns');
      const contador = document.getElementById('contador');
      corpo.innerHTML = '';

      const filtrados = data.filter(i => i.status == 1 && (!filtroEmpresa || i.id_empresa === filtroEmpresa));

      if (resumo) resumo.textContent = `Foram encontradas ${filtrados.length} VPNs conectadas.`;

      if (contador) contador.textContent = `Total: ${filtrados.length}`;

      if (!filtrados.length) {
        corpo.innerHTML = '<tr><td colspan="3">Nenhum registro encontrado.</td></tr>';
        return;
      }

      filtrados.forEach(i => {
        const status = '<span ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#28a745" viewBox="0 0 16 16"><circle cx="8" cy="8" r="8"/></svg></span>';
        corpo.innerHTML += `<tr><td>${i.id_empresa}</td><td>${i.ip}</td><td>${status}</td></tr>`;
      });
    })
    .catch(() => {
      document.getElementById('tabela-body').innerHTML = '<tr><td colspan="3">Erro ao carregar dados.</td></tr>';
    });
}


function carregarVpnsDesconectadas(filtroEmpresa = null) {
  fetch('/DastboardV2/adm/shared/dados.php')

    .then(r => r.json())
    .then(data => {
      const corpo = document.getElementById('tabela-body');
      const resumo = document.getElementById('off_Vpns');
      const contador = document.getElementById('contador');
      corpo.innerHTML = '';


      const filtrados = data.filter(i => i.status == 0 && (!filtroEmpresa || i.id_empresa === filtroEmpresa));

      if (resumo) resumo.textContent = `Foram encontradas ${filtrados.length} VPNs desconectadas.`;

      if (contador) contador.textContent = `Total: ${filtrados.length}`;

      if (!filtrados.length) {
        corpo.innerHTML = '<tr><td colspan="3">Nenhum registro encontrado.</td></tr>';
        return;
      }

      filtrados.forEach(i => {
        const status = '<span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#ae1b1b " viewBox="0 0 16 16"><circle cx="8" cy="8" r="8"/></svg></span>';
        corpo.innerHTML += `<tr"><td>${i.id_empresa}</td><td>${i.ip}</td><td>${status}</td></tr>`;
      });
    })
    .catch(() => {
      document.getElementById('tabela-body').innerHTML = '<tr><td colspan="3">Erro ao carregar dados.</td></tr>';
    });
}

loadPage('dashboard');
