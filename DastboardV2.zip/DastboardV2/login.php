<?php
session_start();
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['username'];
    $senha = $_POST['password'];

    $sql = "SELECT * FROM contas WHERE usuario = ? AND senha = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $usuario, $senha);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if ($row['identificador'] == "Admin") {
            header("Location: /DastboardV2/adm/index.html");
        } 
        if ($row['identificador'] == "Europort") {
            header("Location: /DastboardV2/cliente/europort/index.html");
        }
        if ($row['identificador'] == "Kapa") {
            header("Location: /DastboardV2/cliente/kapa/index.html");
        }
        exit();
    } else {
        $msg = urlencode("Usuário ou senha incorretos.");
        header("Location: index.html?erro=$msg"); 
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
