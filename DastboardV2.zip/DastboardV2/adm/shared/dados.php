<?php
header('Content-Type: application/json');

$conn = new mysqli("localhost", "root", "", "vpns");

if ($conn->connect_error) {
  echo json_encode(["erro" => "Erro de conexão: " . $conn->connect_error]);
  exit;
}

$sql = "SELECT * FROM vpns";
$result = $conn->query($sql);

$dados = [];

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $dados[] = $row;
  }
}

$conn->close();

echo json_encode($dados);
