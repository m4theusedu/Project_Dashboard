<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "sistema";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$usuario = $_POST['usuario'];
$senha = $_POST['senha'];
$identificador = $_POST['identificador'];

$stmt = $conn->prepare("INSERT INTO contas (usuario, senha, identificador) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $usuario, $senha, $identificador);

if ($stmt->execute()) {
    echo "Conta adicionada com sucesso!";
} else {
    echo "Erro ao adicionar: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
